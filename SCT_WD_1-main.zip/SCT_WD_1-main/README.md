# OctaNet Landing Page 🌐

## 🛠️ Technologies Used

- HTML5
- CSS3
- JavaScript (Vanilla)

## 📱 Features

- Fully responsive design for desktop, tablet, and mobile devices
- Clean and modern UI/UX
- Smooth scrolling and navigation
- Interactive buttons and hover effects
- Contact section with basic form elements
